The images in this directory are part of the GUIEdit module
for PmWiki, Copyright 2005-2006 Patrick R. Michaud (pmichaud@pobox.com)
These images are part of PmWiki; you can redistribute it and/or modify
them under the terms of the GNU General Public License as published
by the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.  See lib/pmwiki/pmwiki.php for full details.
